namespace ViewModelFun.Models;

public class User
{
    public string? Name { get; set; }
}