namespace ViewModelFun.Models;

public class Number
{
    public int[] DisplayNumbers { get; set; } = { 1, 2, 10, 21, 8, 7, 3 };
}