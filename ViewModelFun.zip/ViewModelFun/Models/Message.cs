namespace ViewModelFun.Models;

public class Message
{
    public string? DisplayMessage { get; set; }
}